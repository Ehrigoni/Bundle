Esse projeto foi desenvolvido durante a semana OmnisStack 11.0 (23/03/2020-27/03/2020),
promovido pela empresa RocketSeat(https://rocketseat.com.br/).
O projeto está organizado em três partes:
- um backEnd desenvolvido na tecnologia Node.js;
- um frontEnd desenvolvido na tecnologia ReactJS;
- um aplicativo mobile desenvolvido na tecnologia ReactNative;

Quanto as funções desempenhadas por cada parte:
- backend: responsável pela implementação das regas de negócio como cadastramento e exclusão de ONGs e listagem das mesmas. Responsável pelo cadastro de casos de cada ONG, bem como sua exclusão e listagem. Realiza a função de Login de uma ONG usuária e apresenta um perfil de casos da mesma.

- frontEnd: responsável por implementar uma interface para que as ONGs interajam com o sistema fazendo uso de uma api que faz acesso as funções implementadas no backend.

- aplicativo mobile: tem a função de implementar uma interface que liste as ONGs e seus respectivos casos para que potenciais doadores possam entrar em contato por meio de e-mail ou whatsApp fazendo uso de um botão no aplicativo.



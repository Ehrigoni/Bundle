const express = require('express');

const routes = express.Router();
const { celebrate, Segments, Joi } = require('celebrate');
const OngController = require('./controllers/OngController');
const IncidentController = require('./controllers/IncidentController');
const ProfileController = require('./controllers/ProfileController');
const SessionController = require('./controllers/SessionController');


routes.post('/session', SessionController.create);

routes.post('/ong', OngController.create); 

/**
 * Tipos de parâmetros a serem validados
 * Query params
 * Route
 * Body
 */
routes.get('/ong', celebrate({
    [Segments.BODY]: Joi.object().keys({
        name: Joi.string().required(),
        email: Joi.string().required().email(),
        whatsapp: Joi.number().required().min(10).max(11),
        city: Joi.string().required(),
        uf: Joi.string().required().length(2)
    })
}), OngController.index);

routes.post('/incident', IncidentController.create);

routes.get('/incident', celebrate({
    [Segments.QUERY]: Joi.object().keys({
        page: Joi.number(),
    })
}), IncidentController.index);


routes.delete('/incident/:id', celebrate({
    [Segments.PARAMS]: Joi.object()
                          .keys({
                                id: Joi.number().required(),        
                                })
}), IncidentController.delete);


routes.get('/profile', celebrate({
    [Segments.HEADERS]: Joi.object({
        authorization: Joi.string().required(),
    }).unknown(),
}), ProfileController.index);

module.exports = routes;